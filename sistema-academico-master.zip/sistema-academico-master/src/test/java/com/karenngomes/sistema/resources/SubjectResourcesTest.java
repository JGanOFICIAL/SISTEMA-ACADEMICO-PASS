package com.karenngomes.sistema.resources;

public class SubjectResourcesTest {

}
